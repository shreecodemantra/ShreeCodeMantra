# -*- coding: utf-8 -*-
"""
Created on Tue May 10 15:30:14 2022

@author: INBOTICS
"""
from web3 import Web3, HTTPProvider
import json

def BlockchainforContract():
    acc1privatekey='0x255925c9241db7f6514addb8fd694cb84831e8dd2d9263ffcd07af1dfc394c02'
    deployed_contract_address = '0xF5D5a4B7DbD7c74361e9979F6bC06EAa0a043BFb'
    # truffle development blockchain address
    blockchain_address = 'http://127.0.0.1:8545'
    # Client instance to interact with the blockchain
    web3 = Web3(HTTPProvider(blockchain_address))
    # Set the default account (so we don't need to set the "from" for every transaction call)
    web3.eth.defaultAccount = web3.eth.accounts[0]
    
    # Path to the compiled contract JSON file
    compiled_contract_path = 'HumantRafficking.json'

    with open(compiled_contract_path) as file:
        contract_json = json.load(file)  # load contract info as JSON
        contract_abi = contract_json['abi']  # fetch contract's abi - necessary to call its functions
    #print(contract_abi)
    # Fetch deployed contract reference
    contract = web3.eth.contract(address=deployed_contract_address, abi=contract_abi)
    
    nonce = web3.eth.getTransactionCount(web3.eth.accounts[0])
    return contract,nonce,web3,acc1privatekey
    