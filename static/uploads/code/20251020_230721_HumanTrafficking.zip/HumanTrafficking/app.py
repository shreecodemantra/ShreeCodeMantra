from flask import Flask, session
from flask import render_template,request, redirect, url_for
from werkzeug.utils import secure_filename
import os
from register import register_yourself
from mark_attendance import mark_your_attendance_image,mark_your_attendance
from connectToTruffle import BlockchainforContract
import smtplib 
from email.mime.multipart import MIMEMultipart 
from email.mime.text import MIMEText 
from email.mime.base import MIMEBase 
from email import encoders
import geocoder 

app = Flask(__name__)

app.config['UPLOAD_C_FILES'] = 'static/files/criminals/'
app.config['UPLOAD_V_FILES'] = 'static/files/victims/'
app.secret_key = 'any random string'

contract,nonce,web3,acc1privatekey=BlockchainforContract()

def sendemailtouser(usermail, cmpimg, ogpass):   
    fromaddr = "pranalibscproject@gmail.com"
    toaddr = usermail 
    msg = MIMEMultipart()   
    msg['From'] = fromaddr   
    msg['To'] = toaddr 
  
    # storing the subject  
    msg['Subject'] = "Human trafficking system alert"
    
    # Constructing the body of the email with the provided information
    name, age, mobileno, address, aadhar_no, offence, current_location, current_coordinates = ogpass
    body = f"""\
    <html>
      <body>
        <p><strong>Name:</strong> {name}</p>
        <p><strong>Age:</strong> {age}</p>
        <p><strong>Title:</strong> {offence}</p>
        <p><strong>Mobile Number:</strong> {mobileno}</p>
        <p><strong>Address:</strong> {address}</p>
        <p><strong>Aadhar Number:</strong> {aadhar_no}</p>
        <p><strong>Current Location:</strong> {current_location}</p>
        <p><strong>Current Coordinates:</strong> {current_coordinates}</p>
      </body>
    </html>
    """
    
    msg.attach(MIMEText(body, 'html')) 
    filename = cmpimg
    attachment = open(cmpimg, "rb") 
    p = MIMEBase('application', 'octet-stream') 
    p.set_payload((attachment).read()) 
    encoders.encode_base64(p) 
   
    p.add_header('Content-Disposition', "attachment; filename= %s" % filename) 
    msg.attach(p) 
    s = smtplib.SMTP('smtp.gmail.com', 587)
    s.starttls() 
    s.login(fromaddr, "wkwfgosewcljcpqh") 
    text = msg.as_string() 
    s.sendmail(fromaddr, toaddr, text) 
    s.quit()

@app.route('/')
def index():
    return render_template('index.html', current_url=request.path)

@app.route('/SignUp')
def SignUp():
    return render_template('Sign-Up.html', current_url=request.path)

@app.route('/SignIn')
def SignIn():
    return render_template('Sign-In.html', current_url=request.path)

@app.route('/SessionHandle',methods=['POST'])
def SessionHandle():
    if request.method == "POST":
        details = request.form
        username = details['username']
        fname = details['fname']
        session['username'] = username
        session['fname'] = fname
        strofuser = username
        return strofuser

@app.route('/homePage')
def homePage():
    return render_template('homePage.html', current_url=request.path)

@app.route('/addCriminal',methods=['POST','GET'])
def addCriminal():
    return render_template('Add-Criminal.html', current_url=request.path)

@app.route('/addVictim',methods=['POST','GET'])
def addVictim():
    return render_template('Add-Victim.html', current_url=request.path)

@app.route('/viewData',methods=['POST','GET'])
def viewData():
    return render_template('View-Data.html', current_url=request.path)

@app.route('/searchPerson',methods=['POST','GET'])
def searchPerson():
    return render_template('Search-Person.html', current_url=request.path)

@app.route('/addCriminalData',methods=['POST','GET'])
def addCriminalData():
    if request.method == "POST":
        
        image= request.files['image'] 
        fname = request.form['fname']
        age = request.form['age'] 
        gender = request.form['gender'] 
        address = request.form['address'] 
        contact = request.form['contactno']
        aadhar = request.form['aadhar']
        offense = request.form['offense']
        arrest = request.form['arrest']
        
        filename_secure = secure_filename(image.filename)
        image.save(os.path.join(app.config['UPLOAD_C_FILES'], filename_secure))
        filename1 = os.path.join(app.config['UPLOAD_C_FILES'], filename_secure)   
        register_yourself(fname)
        ListOfFile = {'a':filename1,'b':fname,'c':age,'d':gender,
                      'e':address,'f':contact,'g':aadhar,'h':offense,'i':arrest}
        
        return ListOfFile  
    return render_template('Add-Criminal.html',data={}) 

@app.route('/addVictimData',methods=['POST','GET'])
def addVictimData():
    if request.method == "POST":
        
        image= request.files['image'] 
        fname = request.form['fname']
        age = request.form['age'] 
        gender = request.form['gender'] 
        address = request.form['address'] 
        contact = request.form['contactno']
        aadhar = request.form['aadhar']
        statements = request.form['statements']
        evidence = request.form['evidence']
        
        filename_secure = secure_filename(image.filename)
        image.save(os.path.join(app.config['UPLOAD_V_FILES'], filename_secure))
        filename1 = os.path.join(app.config['UPLOAD_V_FILES'], filename_secure)   
        register_yourself(fname)
        ListOfFile = {'a':filename1,'b':fname,'c':age,'d':gender,
                      'e':address,'f':contact,'g':aadhar,'h':statements,'i':evidence}
        
        return ListOfFile  
    return render_template('Add-Victim.html',data={}) 

@app.route('/getPersonData',methods=['POST','GET'])
def getPersonData():
    if request.method == "POST":
        details = request.form
        info = details['data']
        data=info.split('|')
        print(data)
        return render_template('Info.html',data=data,current_url='/viewData')
    return render_template('Info.html',data={}) 

@app.route('/checkPersonFace',methods=['POST','GET'])
def checkPersonFace():
    if request.method == "POST":
        
        image= request.files['image'] 
        
        filename_secure = secure_filename(image.filename)
        image.save('static/image.'+filename_secure.split('.')[1])
        
        marked,persons = mark_your_attendance_image('static/image.'+filename_secure.split('.')[1])
        print(marked)
        print(persons)
        if marked:
            mainlst = []
            for oneperson in persons:
                print(oneperson)
                listoftrancation=contract.functions.loginPerson('').call()
                
                for singlelist in listoftrancation:                    
                    if singlelist[2]==oneperson:
                        print(singlelist)
                        mainlst.append(singlelist)
        
            return mainlst
        else:
            return []
    return render_template('Search-Person.html', current_url='/searchPerson')

@app.route('/liveSurveillance',methods=['POST','GET'])
def liveSurveillance():
    
    marked,persons = mark_your_attendance()
    print(marked)
    print(persons)
    if marked:
        mainlst = []
        for oneperson in persons:
            print(oneperson)
            listoftrancation=contract.functions.loginPerson('').call()
            
            for singlelist in listoftrancation:                    
                if singlelist[2]==oneperson:
                    mainlst.append(list(singlelist))
        try:
            location = geocoder.ip('me')
            adress = location.address
            latlong = location.latlng
        except:
            print("Unable to retrieve the current location.")
            adress = "None"
            latlong = "0.0 0.0"
    
        allPoliceData=contract.functions.login('').call()
        for policemail in allPoliceData:
            print()
            print(policemail[4])
            for data in mainlst:
                print(data)
                print()
                sendemailtouser(str(policemail[4]), data[2]+".jpg", [data[2], data[3], data[6], data[5], data[7], data[8], str(adress), str(latlong)])
            
    return redirect(url_for("homePage"))

if __name__ == "__main__":
    app.run("0.0.0.0")
    # app.run(debug=True)
    