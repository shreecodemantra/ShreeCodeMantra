import smtplib 
from email.mime.multipart import MIMEMultipart 
from email.mime.text import MIMEText 
from email.mime.base import MIMEBase 
from email import encoders 

def sendemailtouser(usermail, cmpimg, ogpass):   
    fromaddr = "pranalibscproject@gmail.com"
    toaddr = usermail 
    msg = MIMEMultipart()   
    msg['From'] = fromaddr   
    msg['To'] = toaddr 
  
    # storing the subject  
    msg['Subject'] = "Human trafficking system alert"
    
    # Constructing the body of the email with the provided information
    name, age, mobileno, address, aadhar_no, offence, current_location, current_coordinates = ogpass
    body = f"""\
    <html>
      <body>
        <p><strong>Name:</strong> {name}</p>
        <p><strong>Age:</strong> {age}</p>
        <p><strong>Title:</strong> {offence}</p>
        <p>Mobile Number: {mobileno}</p>
        <p>Address: {address}</p>
        <p>Aadhar Number: {aadhar_no}</p>
        <p>Current Location: {current_location}</p>
        <p>Current Coordinates: {current_coordinates}</p>
      </body>
    </html>
    """
    
    msg.attach(MIMEText(body, 'html')) 
    filename = cmpimg
    attachment = open(cmpimg, "rb") 
    p = MIMEBase('application', 'octet-stream') 
    p.set_payload((attachment).read()) 
    encoders.encode_base64(p) 
   
    p.add_header('Content-Disposition', "attachment; filename= %s" % filename) 
    msg.attach(p) 
    s = smtplib.SMTP('smtp.gmail.com', 587)
    s.starttls() 
    s.login(fromaddr, "wkwfgosewcljcpqh") 
    text = msg.as_string() 
    s.sendmail(fromaddr, toaddr, text) 
    s.quit()  

# Example usage:
sendemailtouser("yashsalvi1999@gmail.com", "a.jpg", ["Yash Salvi", "25", "9965854895", "Mumbai, Maharashtra", "965854586585", "Robbery", "Pune", "19.2588 27.5586"])

# import geocoder

# def get_current_location():
#     try:
#         # Get current location
#         location = geocoder.ip('me')
#         return str(location.address),location.latlng
#     except:
#         print("Unable to retrieve the current location.")
#         return "None",[]

# if __name__ == "__main__":
#     a=get_current_location()
#     print(a)
